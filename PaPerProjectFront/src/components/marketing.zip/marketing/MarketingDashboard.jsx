import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import {
  Loader2,
  TrendingUp,
  Target,
  BarChart3,
  MessageSquare,
  FileText,
  Bell,
  Megaphone,
  Sparkles,
  Mail,
  Plus,
  Pencil,
  Trash2,
  Send,
  X,
  ChevronLeft,
  ChevronRight,
  BarChart3 as BarChartIcon,
} from 'lucide-react';
import marketingAgentService, {
  getSavedGraphPrompts,
  isGraphPromptOnDashboard,
} from '@/services/marketingAgentService';
import MarketingQA from './MarketingQA';
import MarketResearch from './MarketResearch';
import Campaigns from './Campaigns';
import Documents from './Documents';
import Notifications from './Notifications';

const STATUS_LABELS = {
  draft: 'Draft',
  active: 'Active',
  paused: 'Paused',
  completed: 'Completed',
  scheduled: 'Scheduled',
  cancelled: 'Cancelled',
};

const STATUS_BADGE_CLASS = {
  draft: 'bg-gray-100 text-gray-800',
  active: 'bg-green-100 text-green-800',
  paused: 'bg-yellow-100 text-yellow-800',
  completed: 'bg-blue-100 text-blue-800',
  scheduled: 'bg-indigo-100 text-indigo-800',
  cancelled: 'bg-red-100 text-red-800',
};

const formatDate = (iso) => {
  if (!iso) return '—';
  try {
    const d = new Date(iso);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return iso;
  }
};

const ACCOUNT_TYPE_LABELS = {
  gmail: 'Gmail',
  outlook: 'Outlook',
  hostinger: 'Hostinger',
  smtp: 'Custom SMTP',
  custom: 'Custom SMTP',
};

const EMAIL_ACCOUNT_TYPES = [
  { value: 'gmail', label: 'Gmail' },
  { value: 'outlook', label: 'Outlook' },
  { value: 'hostinger', label: 'Hostinger' },
  { value: 'smtp', label: 'Custom SMTP' },
];

const SMTP_DEFAULTS = {
  gmail: { host: 'smtp.gmail.com', port: 587, useTLS: true, useSSL: false },
  outlook: { host: 'smtp-mail.outlook.com', port: 587, useTLS: true, useSSL: false },
  hostinger: { host: 'smtp.hostinger.com', port: 587, useTLS: true, useSSL: false },
  smtp: { host: '', port: 587, useTLS: true, useSSL: false },
};

const defaultEmailForm = () => ({
  name: '',
  account_type: 'smtp',
  email: '',
  smtp_host: '',
  smtp_port: 587,
  smtp_username: '',
  smtp_password: '',
  use_tls: true,
  use_ssl: false,
  is_gmail_app_password: false,
  is_active: true,
  is_default: false,
  enable_imap_sync: false,
  imap_host: '',
  imap_port: 993,
  imap_username: '',
  imap_password: '',
  imap_use_ssl: true,
});

const MarketingDashboard = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [campaignsLoading, setCampaignsLoading] = useState(true);
  const [emailAccountsLoading, setEmailAccountsLoading] = useState(false);
  const [emailAccounts, setEmailAccounts] = useState([]);
  const [stats, setStats] = useState({
    totalCampaigns: 0,
    activeCampaigns: 0,
  });
  const [campaigns, setCampaigns] = useState([]);
  const [campaignsPage, setCampaignsPage] = useState(1);
  const [campaignsTotal, setCampaignsTotal] = useState(0);
  const DASHBOARD_CAMPAIGNS_PAGE_SIZE = 10;

  // Email tab: sidebar and modals
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [addOrEditModalOpen, setAddOrEditModalOpen] = useState(false);
  const [editingAccountId, setEditingAccountId] = useState(null);
  const [emailForm, setEmailForm] = useState(defaultEmailForm());
  const [emailFormLoading, setEmailFormLoading] = useState(false);
  const [showImap, setShowImap] = useState(false);
  const [testModalOpen, setTestModalOpen] = useState(false);
  const [testAccountId, setTestAccountId] = useState(null);
  const [testEmailTo, setTestEmailTo] = useState('');
  const [testLoading, setTestLoading] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [notificationUnreadCount, setNotificationUnreadCount] = useState(0);
  const [dashboardGraphPrompts, setDashboardGraphPrompts] = useState([]);
  const [savedGraphPrompts, setSavedGraphPrompts] = useState([]);
  const [savedGraphsLoading, setSavedGraphsLoading] = useState(false);
  const [viewingGraphId, setViewingGraphId] = useState(null);
  const [viewingGraphResult, setViewingGraphResult] = useState(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchSavedGraphPrompts = async () => {
    try {
      setSavedGraphsLoading(true);
      const response = await getSavedGraphPrompts();
      if (response?.status === 'success' && Array.isArray(response.data)) {
        setSavedGraphPrompts(response.data);
      } else {
        setSavedGraphPrompts([]);
      }
    } catch (error) {
      console.error('Fetch saved graphs error:', error);
      setSavedGraphPrompts([]);
    } finally {
      setSavedGraphsLoading(false);
    }
  };

  const fetchNotificationUnreadCount = useCallback(async () => {
    try {
      const response = await marketingAgentService.getNotifications({ unread_only: true });
      if (response.status === 'success' && response.data && typeof response.data.unread_count === 'number') {
        setNotificationUnreadCount(response.data.unread_count);
      } else {
        setNotificationUnreadCount(0);
      }
    } catch {
      setNotificationUnreadCount(0);
    }
  }, []);

  useEffect(() => {
    fetchNotificationUnreadCount();
  }, [fetchNotificationUnreadCount]);

  useEffect(() => {
    if (activeTab === 'notifications') {
      fetchNotificationUnreadCount();
    }
  }, [activeTab, fetchNotificationUnreadCount]);

  useEffect(() => {
    if (activeTab === 'dashboard') {
      fetchCampaigns(campaignsPage);
      getSavedGraphPrompts()
        .then((res) => {
          if (res?.status === 'success' && Array.isArray(res.data)) {
            setDashboardGraphPrompts(res.data.filter(isGraphPromptOnDashboard));
          }
        })
        .catch(() => setDashboardGraphPrompts([]));
    } else if (activeTab === 'email') {
      fetchEmailAccounts();
    } else if (activeTab === 'saved-graphs') {
      fetchSavedGraphPrompts();
    }
  }, [activeTab, campaignsPage]);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await marketingAgentService.getMarketingDashboard();

      if (response.status === 'success' && response.data) {
        setStats({
          totalCampaigns: response.data.stats?.total_campaigns || 0,
          activeCampaigns: response.data.stats?.active_campaigns || 0,
        });
      }
    } catch {
      setStats({ totalCampaigns: 0, activeCampaigns: 0 });
    } finally {
      setLoading(false);
    }
  };

  const fetchCampaigns = async (page = 1) => {
    try {
      setCampaignsLoading(true);
      const response = await marketingAgentService.listCampaigns({
        page,
        limit: DASHBOARD_CAMPAIGNS_PAGE_SIZE,
      });
      if (response?.status === 'success' && response?.data) {
        setCampaigns(response.data.campaigns || []);
        setCampaignsTotal(response.data.total ?? 0);
      }
    } catch {
      setCampaigns([]);
      setCampaignsTotal(0);
    } finally {
      setCampaignsLoading(false);
    }
  };

  const fetchEmailAccounts = async () => {
    try {
      setEmailAccountsLoading(true);
      const response = await marketingAgentService.listEmailAccounts();
      const list = response?.status === 'success' && response?.data ? response.data : [];
      setEmailAccounts(list);
      return list;
    } catch {
      setEmailAccounts([]);
      return [];
    } finally {
      setEmailAccountsLoading(false);
    }
  };

  const applyEmailTypeDefaults = (accountType) => {
    const d = SMTP_DEFAULTS[accountType] || SMTP_DEFAULTS.smtp;
    setEmailForm((prev) => ({
      ...prev,
      account_type: accountType,
      smtp_host: d.host,
      smtp_port: d.port,
      use_tls: d.useTLS,
      use_ssl: d.useSSL,
      is_gmail_app_password: accountType === 'gmail',
    }));
  };

  const openAddEmailAccount = () => {
    setEditingAccountId(null);
    setEmailForm(defaultEmailForm());
    applyEmailTypeDefaults('smtp');
    setShowImap(false);
    setAddOrEditModalOpen(true);
  };

  const openEditEmailAccount = useCallback(async (id) => {
    setEditingAccountId(id);
    setAddOrEditModalOpen(true);
    try {
      const res = await marketingAgentService.getEmailAccount(id);
      if (res?.status === 'success' && res?.data) {
        const d = res.data;
        setEmailForm({
          name: d.name || '',
          account_type: d.account_type || 'smtp',
          email: d.email || '',
          smtp_host: d.smtp_host || '',
          smtp_port: d.smtp_port ?? 587,
          smtp_username: d.smtp_username || '',
          smtp_password: '',
          use_tls: d.use_tls ?? true,
          use_ssl: d.use_ssl ?? false,
          is_gmail_app_password: d.is_gmail_app_password ?? false,
          is_active: d.is_active ?? true,
          is_default: d.is_default ?? false,
          enable_imap_sync: d.enable_imap_sync ?? false,
          imap_host: d.imap_host || '',
          imap_port: d.imap_port ?? 993,
          imap_username: d.imap_username || '',
          imap_password: '',
          imap_use_ssl: d.imap_use_ssl ?? true,
        });
        setShowImap(d.enable_imap_sync ?? false);
      }
    } catch (e) {
      toast({ title: 'Error', description: e?.message || 'Failed to load account', variant: 'destructive' });
    }
  }, [toast]);

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    if (!emailForm.name?.trim()) {
      toast({ title: 'Validation', description: 'Account name is required.', variant: 'destructive' });
      return;
    }
    if (!emailForm.email?.trim()) {
      toast({ title: 'Validation', description: 'Email is required.', variant: 'destructive' });
      return;
    }
    if (!emailForm.smtp_host?.trim()) {
      toast({ title: 'Validation', description: 'SMTP host is required.', variant: 'destructive' });
      return;
    }
    if (!editingAccountId && !emailForm.smtp_password) {
      toast({ title: 'Validation', description: 'SMTP password is required for new account.', variant: 'destructive' });
      return;
    }
    setEmailFormLoading(true);
    try {
      const payload = {
        name: emailForm.name.trim(),
        account_type: emailForm.account_type,
        email: emailForm.email.trim(),
        smtp_host: emailForm.smtp_host.trim(),
        smtp_port: Number(emailForm.smtp_port) || 587,
        smtp_username: (emailForm.smtp_username || '').trim() || emailForm.email.trim(),
        use_tls: emailForm.use_tls,
        use_ssl: emailForm.use_ssl,
        is_gmail_app_password: emailForm.is_gmail_app_password,
        is_active: emailForm.is_active,
        is_default: emailForm.is_default,
        enable_imap_sync: emailForm.enable_imap_sync,
        imap_host: emailForm.imap_host || '',
        imap_port: emailForm.imap_port ? Number(emailForm.imap_port) : null,
        imap_username: emailForm.imap_username || '',
        imap_use_ssl: emailForm.imap_use_ssl,
      };
      if (emailForm.smtp_password) payload.smtp_password = emailForm.smtp_password;
      if (emailForm.imap_password) payload.imap_password = emailForm.imap_password;

      if (editingAccountId) {
        const res = await marketingAgentService.updateEmailAccount(editingAccountId, payload);
        if (res?.status === 'success') {
          toast({ title: 'Success', description: res?.data?.message || 'Account updated.' });
          setAddOrEditModalOpen(false);
          fetchEmailAccounts();
          if (selectedAccount?.id === editingAccountId) setSelectedAccount(null);
        } else {
          toast({ title: 'Error', description: res?.message || 'Update failed.', variant: 'destructive' });
        }
      } else {
        const res = await marketingAgentService.createEmailAccount(payload);
        if (res?.status === 'success') {
          toast({ title: 'Success', description: res?.data?.message || 'Account created.' });
          setAddOrEditModalOpen(false);
          fetchEmailAccounts();
        } else {
          toast({ title: 'Error', description: res?.message || 'Create failed.', variant: 'destructive' });
        }
      }
    } catch (e) {
      toast({ title: 'Error', description: e?.message || 'Request failed.', variant: 'destructive' });
    } finally {
      setEmailFormLoading(false);
    }
  };

  const handleEmailDelete = async (id, name) => {
    setDeleteLoading(true);
    try {
      const res = await marketingAgentService.deleteEmailAccount(id);
      if (res?.status === 'success') {
        toast({ title: 'Success', description: res?.data?.message || 'Account deleted.' });
        setDeleteConfirm(null);
        setSelectedAccount(null);
        fetchEmailAccounts();
      } else {
        toast({ title: 'Error', description: res?.message || 'Delete failed.', variant: 'destructive' });
      }
    } catch (e) {
      toast({ title: 'Error', description: e?.message || 'Delete failed.', variant: 'destructive' });
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleDeleteGraphPrompt = async (promptId) => {
    try {
      const res = await marketingAgentService.deleteGraphPrompt(promptId);
      if (res?.status === 'success') {
        toast({ title: 'Success', description: 'Graph prompt deleted.' });
        fetchSavedGraphPrompts();
        // Clear viewing if deleted prompt
        if (viewingGraphId === promptId) {
          setViewingGraphId(null);
          setViewingGraphResult(null);
        }
      } else {
        toast({ title: 'Error', description: res?.message || 'Delete failed.', variant: 'destructive' });
      }
    } catch (error) {
      console.error('Delete graph prompt error:', error);
      toast({ title: 'Error', description: 'Failed to delete graph prompt.', variant: 'destructive' });
    }
  };

  const normalizePromptText = (text) =>
    String(text || '')
      .replace(/\u200B|\u200C|\u200D|\uFEFF/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();

  const getPayloadFromLocalCache = (prompt) => {
    try {
      const cache = JSON.parse(localStorage.getItem('marketing_saved_graph_payloads') || '{}');
      const byId = cache[String(prompt?.id)];
      if (byId?.chart) {
        return {
          chart: byId.chart,
          title: byId.title || prompt?.title || 'Saved Graph',
          insights: byId.insights || [],
        };
      }
    } catch {}
    return null;
  };

  const getPayloadFromChatHistory = (prompt) => {
    try {
      const chats = JSON.parse(localStorage.getItem('marketing_qa_chats') || '[]');
      const target = normalizePromptText(prompt?.prompt);
      if (!target) return null;

      for (const chat of chats) {
        const messages = Array.isArray(chat?.messages) ? chat.messages : [];
        for (let i = 0; i < messages.length - 1; i++) {
          const userMsg = messages[i];
          const assistantMsg = messages[i + 1];
          if (
            userMsg?.role === 'user' &&
            assistantMsg?.role === 'assistant' &&
            assistantMsg?.responseData?.isGraph &&
            normalizePromptText(userMsg?.content) === target &&
            assistantMsg?.responseData?.chart
          ) {
            return {
              chart: assistantMsg.responseData.chart,
              title: assistantMsg.responseData.chartTitle || prompt?.title || 'Saved Graph',
              insights: assistantMsg.responseData.insights || [],
            };
          }
        }
      }
    } catch {}
    return null;
  };

  const getSavedGraphPayload = (prompt) => {
    const chart =
      prompt?.chart ||
      prompt?.chart_data ||
      prompt?.graph_data ||
      prompt?.generated_chart ||
      prompt?.result?.chart ||
      prompt?.data?.chart ||
      null;

    const title =
      prompt?.graph_title ||
      prompt?.generated_title ||
      prompt?.result?.title ||
      prompt?.data?.title ||
      prompt?.title ||
      'Saved Graph';

    const insights =
      prompt?.insights ||
      prompt?.result?.insights ||
      prompt?.data?.insights ||
      null;

    if (chart) return { chart, title, insights };

    const cached = getPayloadFromLocalCache(prompt);
    if (cached) return cached;

    const fromChat = getPayloadFromChatHistory(prompt);
    if (fromChat) return fromChat;

    return null;
  };

  const handleViewGraph = (prompt) => {
    setViewingGraphId(prompt.id);
    const savedPayload = getSavedGraphPayload(prompt);
    if (!savedPayload) {
      setViewingGraphResult({
        title: prompt?.title || 'Saved Graph',
        insights: [],
        chart: null,
      });
      return;
    }
    setViewingGraphResult(savedPayload);
  };

  const openTestEmailAccount = (account) => {
    setTestAccountId(account.id);
    setTestEmailTo(account.email || '');
    setTestModalOpen(true);
  };

  const handleTestEmailAccount = async () => {
    const email = (testEmailTo || '').trim();
    if (!email) {
      toast({ title: 'Validation', description: 'Enter test email address.', variant: 'destructive' });
      return;
    }
    setTestLoading(true);
    try {
      const res = await marketingAgentService.testEmailAccount(testAccountId, email);
      if (res?.status === 'success') {
        toast({ title: 'Success', description: res?.data?.message || 'Test email sent.' });
        setTestModalOpen(false);
        const list = await fetchEmailAccounts();
        if (selectedAccount?.id === testAccountId) {
          const updated = list.find((a) => a.id === testAccountId);
          if (updated) setSelectedAccount(updated);
        }
      } else {
        toast({ title: 'Test failed', description: res?.message || 'Could not send test email.', variant: 'destructive' });
      }
    } catch (e) {
      toast({ title: 'Test failed', description: e?.message || e?.data?.message || 'Could not send test email.', variant: 'destructive' });
    } finally {
      setTestLoading(false);
    }
  };

  return (
    <div
      className="w-full rounded-2xl max-w-full border border-white/[0.06] p-0 overflow-hidden"
      style={{ background: 'linear-gradient(90deg, #020308 0%, #020308 55%, rgba(10,37,64,0.68) 85%, rgba(14,39,71,0.52) 100%)' }}
    >
    <div className="space-y-6 w-full max-w-full overflow-x-hidden p-4 md:p-6 lg:p-8">
      {/* Chart rendering helper */}
      {(() => {
        // Define renderChart as an IIFE to use in JSX
        window.renderChart = (chartData) => {
          if (!chartData) return null;
          const { type, data, title, color = '#3b82f6', colors } = chartData;
          
          // SimpleBarChart
          const SimpleBarChart = ({ data, colors, height = 250, title }) => {
            if (!data || Object.keys(data).length === 0) return null;
            const maxValue = Math.max(...Object.values(data), 1);
            const defaultColors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];
            const chartColors = colors || defaultColors;
            return (
              <div className="space-y-3" style={{ minHeight: `${height}px` }}>
                {title && <h4 className="font-medium text-sm text-muted-foreground mb-4">{title}</h4>}
                {Object.entries(data).map(([key, value], index) => (
                  <div key={key}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-sm">{key}</span>
                      <span className="font-semibold">{value}</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{
                          width: `${(value / maxValue) * 100}%`,
                          backgroundColor: chartColors[index % chartColors.length],
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            );
          };
          
          // SimplePieChart
          const SimplePieChart = ({ data, colors, title }) => {
            if (!data || Object.keys(data).length === 0) return null;
            const total = Object.values(data).reduce((sum, val) => sum + val, 0);
            if (total === 0) return null;
            const defaultColors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];
            const chartColors = colors || defaultColors;
            let currentAngle = 0;
            const segments = Object.entries(data).map(([key, value], index) => {
              const percentage = (value / total) * 100;
              const sliceAngle = (value / total) * 360;
              const startAngle = currentAngle;
              currentAngle += sliceAngle;
              return { key, value, percentage, startAngle, sliceAngle, color: chartColors[index % chartColors.length] };
            });
            return (
              <div className="flex flex-col items-center gap-4">
                {title && <h4 className="font-medium text-sm text-muted-foreground">{title}</h4>}
                <div className="relative w-48 h-48 sm:w-56 sm:h-56">
                  <svg width="100%" height="100%" viewBox="0 0 200 200" className="transform -rotate-90">
                    {segments.map((segment, index) => {
                      const startRad = (segment.startAngle * Math.PI) / 180;
                      const endRad = ((segment.startAngle + segment.sliceAngle) * Math.PI) / 180;
                      const x1 = 100 + 100 * Math.cos(startRad);
                      const y1 = 100 + 100 * Math.sin(startRad);
                      const x2 = 100 + 100 * Math.cos(endRad);
                      const y2 = 100 + 100 * Math.sin(endRad);
                      const largeArc = segment.sliceAngle > 180 ? 1 : 0;
                      const pathData = `M 100 100 L ${x1} ${y1} A 100 100 0 ${largeArc} 1 ${x2} ${y2} Z`;
                      return <path key={index} d={pathData} fill={segment.color} stroke="white" strokeWidth="2" />;
                    })}
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold">{total}</div>
                      <div className="text-xs text-muted-foreground">Total</div>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 w-full max-w-xs">
                  {segments.map((segment, index) => (
                    <div key={index} className="flex items-center gap-2 text-xs sm:text-sm">
                      <div className="w-3 h-3 rounded shrink-0" style={{ backgroundColor: segment.color }} />
                      <span className="truncate flex-1">{segment.key}</span>
                      <span className="font-medium shrink-0">{segment.percentage.toFixed(1)}%</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          };
          
          // SimpleLineChart
          const SimpleLineChart = ({ data, color = '#3b82f6', height = 200, title }) => {
            if (!data || data.length === 0) return null;
            const values = data.map(d => d.value ?? d.count ?? 0);
            const maxValue = Math.max(...values, 1);
            const labels = data.map(d => d.label ?? d.date ?? d.month ?? '');
            const points = values.map((value, index) => {
              const x = (index / (values.length - 1 || 1)) * 100;
              const y = 100 - (value / maxValue) * 100;
              return `${x},${y}`;
            }).join(' ');
            const areaPoints = `0,100 ${points} 100,100`;
            return (
              <div className="space-y-2">
                {title && <h4 className="font-medium text-sm text-muted-foreground">{title}</h4>}
                <div className="relative w-full" style={{ height: `${height}px` }}>
                  <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <polygon points={areaPoints} fill={`${color}20`} />
                    <polyline points={points} fill="none" stroke={color} strokeWidth="0.5" strokeLinecap="round" strokeLinejoin="round" />
                    {values.map((value, index) => (
                      <circle key={index} cx={(index / (values.length - 1 || 1)) * 100} cy={100 - (value / maxValue) * 100} r="1" fill={color} />
                    ))}
                  </svg>
                  <div className="absolute bottom-0 left-0 right-0 flex justify-between text-[10px] text-muted-foreground px-1">
                    {labels.length <= 7 ? labels.map((label, i) => <span key={i} className="truncate">{label}</span>) : (
                      <><span>{labels[0]}</span><span>{labels[Math.floor(labels.length / 2)]}</span><span>{labels[labels.length - 1]}</span></>
                    )}
                  </div>
                </div>
              </div>
            );
          };
          
          switch (type) {
            case 'bar': return <SimpleBarChart data={data} colors={colors} title={title} />;
            case 'pie': return <SimplePieChart data={data} colors={colors} title={title} />;
            case 'line':
            case 'area': return <SimpleLineChart data={data} color={color} title={title} />;
            default: return null;
          }
        };
        return null;
      })()}

      {(() => {
        // Make renderChart globally available
        const renderChart = window.renderChart;
        return null; 
      })()}
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 w-full">
        {[
          {
            label: 'Total Campaigns',
            value: stats.totalCampaigns,
            sub: 'All time campaigns',
            icon: Target,
            color: '#a78bfa',
            bgColor: 'rgba(167,139,250,0.2)',
            borderColor: 'rgba(167,139,250,0.2)',
            gradientFrom: 'rgba(167,139,250,0.2)',
            gradientTo: 'rgba(147,51,234,0.1)',
          },
          {
            label: 'Active Campaigns',
            value: stats.activeCampaigns,
            sub: 'Currently running',
            icon: TrendingUp,
            color: '#60a5fa',
            bgColor: 'rgba(96,165,250,0.2)',
            borderColor: 'rgba(96,165,250,0.2)',
            gradientFrom: 'rgba(96,165,250,0.2)',
            gradientTo: 'rgba(34,211,238,0.1)',
          },
        ].map((card) => (
          <div
            key={card.label}
            className="relative group w-full min-w-0 rounded-xl backdrop-blur-sm p-5 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg"
            style={{
              border: `1px solid ${card.borderColor}`,
              background: `linear-gradient(135deg, ${card.gradientFrom} 0%, ${card.gradientTo} 100%)`,
            }}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="rounded-lg p-2.5" style={{ backgroundColor: card.bgColor }}>
                <card.icon className="h-5 w-5" style={{ color: card.color }} />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-white/50 tracking-wide">{card.label}</p>
              <p className="text-3xl font-bold text-white tracking-tight">{card.value}</p>
              <p className="text-xs text-white/40">{card.sub}</p>
            </div>
          </div>
        ))}
      </div>
      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="overflow-x-auto pb-1">
          <TabsList
            className="inline-flex w-max min-w-full h-auto p-1 gap-1 rounded-lg bg-[#1a1333] border border-[#3a295a]"
            style={{ boxShadow: '0 2px 12px 0 #a259ff0a' }}
          >
            {[
              { value: 'dashboard', label: 'Dashboard', icon: BarChart3 },
              { value: 'campaigns', label: 'Campaigns', icon: Megaphone },
              { value: 'email', label: 'Email', icon: Mail },
              { value: 'qa', label: 'Q&A', icon: MessageSquare },
              { value: 'research', label: 'Research', icon: Sparkles },
              { value: 'documents', label: 'Documents', icon: FileText },
              { value: 'notifications', label: 'Notifications', icon: Bell, badge: notificationUnreadCount },
              { value: 'saved-graphs', label: 'Saved Graphs', icon: Sparkles },
            ].map((item) => (
              <TabsTrigger
                key={item.value}
                value={item.value}
                className="whitespace-nowrap shrink-0 px-4 py-2 text-sm font-medium rounded-md border transition-all duration-150 relative"
                style={activeTab === item.value
                  ? {
                      background: 'linear-gradient(90deg, #a259ff 0%, #7c3aed 100%)',
                      color: '#fff',
                      border: '1.5px solid #a259ff',
                      boxShadow: '0 0 8px 0 #a259ff55',
                    }
                  : {
                      background: 'rgba(60, 30, 90, 0.22)',
                      color: '#cfc6e6',
                      border: '1.5px solid #2d2342',
                      boxShadow: 'none',
                    }
                }
              >
                <item.icon className="h-4 w-4 mr-2" />
                {item.label}
                {item.badge > 0 && (
                  <span
                    className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground"
                    title={`${item.badge} unread`}
                  >
                    {item.badge > 99 ? '99+' : item.badge}
                  </span>
                )}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <TabsContent value="dashboard" className="space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="space-y-4">
              <Card className="border-white/10 bg-black/20 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex flex-row items-center justify-between">
                    <CardTitle className="text-white">Marketing Overview</CardTitle>
                    {/* Main action buttons */}
                    <div className="flex flex-wrap gap-3">
                      <Button
                        size="sm"
                        className="gap-2"
                        onClick={() => setActiveTab('campaigns')}
                      >
                        <Plus className="h-5 w-5" />
                        Create campaign
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                        onClick={() => setActiveTab('email')}
                      >
                        <Mail className="h-5 w-5" />
                        Email accounts
                      </Button>
                    </div>
                  </div>
                  <CardDescription className="text-white/60">
                    Your marketing campaigns and performance metrics
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Use the Campaigns tab to create and manage email campaigns. Use the Email tab to manage accounts and see sending stats.
                  </p>



                  {/* Campaigns list (like backend campaigns_list.html) */}
                  <div>
                    <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Your Campaigns</h3>
                    {campaignsLoading ? (
                      <div className="flex justify-center py-6">
                        <Loader2 className="h-6 w-6 animate-spin text-primary" />
                      </div>
                    ) : campaigns.length === 0 ? (
                      <div className="border-muted-foreground/30 bg-muted/20 p-8 text-center">
                        <Megaphone className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
                        <p className="text-sm text-muted-foreground mb-4">No campaigns yet.</p>
                        <Button size="lg" className="gap-2" onClick={() => setActiveTab('campaigns')}>
                          <Plus className="h-5 w-5" />
                          Create campaign
                        </Button>
                      </div>
                    ) : (
                      <>
                        <div className=" overflow-hidden">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="bg-muted/50 border-b">
                                <th className="text-left font-semibold p-3">Campaign Name</th>
                                <th className="text-left font-semibold p-3">Status</th>
                                <th className="text-left font-semibold p-3">Type</th>
                                <th className="text-left font-semibold p-3">Created</th>
                                <th className="text-left font-semibold p-3">Scheduled</th>
                                <th className="text-left font-semibold p-3">End Date</th>
                                <th className="text-left font-semibold p-3">Actions</th>
                              </tr>
                            </thead>
                            <tbody>
                              {campaigns.map((campaign) => (
                                <tr key={campaign.id} className="border-b last:border-0 hover:bg-muted/30">
                                  <td className="p-3">
                                    <div className="font-medium">{campaign.name}</div>
                                    {campaign.description && (
                                      <div className="text-muted-foreground truncate max-w-[200px]" title={campaign.description}>
                                        {campaign.description.length > 30 ? campaign.description.slice(0, 30) + '…' : campaign.description}
                                      </div>
                                    )}
                                  </td>
                                  <td className="p-3">
                                    <Badge variant="secondary" className={STATUS_BADGE_CLASS[campaign.status] || 'bg-gray-100 text-gray-800'}>
                                      {STATUS_LABELS[campaign.status] || campaign.status}
                                    </Badge>
                                  </td>
                                  <td className="p-3 text-muted-foreground">{campaign.campaign_type || '—'}</td>
                                  <td className="p-3 text-muted-foreground">{formatDate(campaign.created_at)}</td>
                                  <td className="p-3 text-muted-foreground">{campaign.start_date ? formatDate(campaign.start_date) : '—'}</td>
                                  <td className="p-3 text-muted-foreground">{campaign.end_date ? formatDate(campaign.end_date) : '—'}</td>
                                  <td className="p-3">
                                    <Button
                                      variant="default"
                                      size="sm"
                                      asChild
                                    >
                                      <Link to={`/marketing/dashboard/campaign/${campaign.id}`}>Manage</Link>
                                    </Button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                        {campaignsTotal > DASHBOARD_CAMPAIGNS_PAGE_SIZE && (
                          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 mt-4 border-t">
                            <p className="text-sm text-muted-foreground">
                              Showing page {campaignsPage} of {Math.max(1, Math.ceil(campaignsTotal / DASHBOARD_CAMPAIGNS_PAGE_SIZE))} ({campaignsTotal} total campaigns)
                            </p>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                disabled={campaignsPage <= 1 || campaignsLoading}
                                onClick={() => setCampaignsPage((p) => Math.max(1, p - 1))}
                              >
                                <ChevronLeft className="h-4 w-4" />
                                Previous
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                disabled={campaignsPage >= Math.ceil(campaignsTotal / DASHBOARD_CAMPAIGNS_PAGE_SIZE) || campaignsLoading}
                                onClick={() => setCampaignsPage((p) => p + 1)}
                              >
                                Next
                                <ChevronRight className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>

                  {/* Dashboard Graphs: saved AI graph prompts pinned to dashboard */}
                  {dashboardGraphPrompts.length > 0 && (
                    <div className="mt-6">
                      <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Dashboard Graphs</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {dashboardGraphPrompts.map((p) => (
                          <Card
                            key={p.id}
                            className="cursor-pointer hover:bg-muted/50 transition-colors"
                            onClick={() => {
                              setActiveTab('saved-graphs');
                              setViewingGraphId(p.id);
                              const payload = getSavedGraphPayload(p);
                              setViewingGraphResult(payload);
                            }}
                          >
                            <CardContent className="p-3 flex items-center gap-3">
                              <div className="rounded-lg bg-primary/10 p-2">
                                <BarChartIcon className="h-5 w-5 text-primary" />
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="font-medium text-sm truncate">{p.title}</p>
                                <p className="text-xs text-muted-foreground truncate">{p.prompt}</p>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="email" className="space-y-4">
          <div className="relative flex gap-4">
            <Card className={`border-white/10 bg-black/20 backdrop-blur-sm ${selectedAccount ? 'flex-1 min-w-0' : 'w-full'}`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0">
                <div>
                  <CardTitle className="text-white">Email accounts</CardTitle>
                  <CardDescription className="text-white/60">
                    Accounts used to send campaign emails. Click an account to see details in the sidebar.
                  </CardDescription>
                </div>
                <Button variant="default" size="sm" onClick={openAddEmailAccount}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add email account
                </Button>
              </CardHeader>
              <CardContent>
                {emailAccountsLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : emailAccounts.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <Mail className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p className="font-medium">No email accounts</p>
                    <p className="text-sm mt-1">Add an account to send campaign emails from sequences.</p>
                    <Button className="mt-4" onClick={openAddEmailAccount}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add email account
                    </Button>
                  </div>
                ) : (
                  <div className="rounded-lg border overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-muted/50 border-b">
                          <th className="text-left font-semibold p-3">Account</th>
                          <th className="text-left font-semibold p-3">Email</th>
                          <th className="text-left font-semibold p-3">Type</th>
                          <th className="text-center font-semibold p-3">Status</th>
                          <th className="text-center font-semibold p-3">Test</th>
                          <th className="text-center font-semibold p-3">Sent</th>
                          {/* <th className="text-center font-semibold p-3">Opened</th> */}
                          <th className="text-center font-semibold p-3">Clicked</th>
                          {/* <th className="text-center font-semibold p-3">Open rate</th> */}
                          {/* <th className="text-center font-semibold p-3">Click rate</th> */}
                        </tr>
                      </thead>
                      <tbody>
                        {emailAccounts.map((acc) => (
                          <tr
                            key={acc.id}
                            className={`border-b last:border-0 hover:bg-muted/30 cursor-pointer ${selectedAccount?.id === acc.id ? 'bg-muted/50' : ''}`}
                            onClick={() => setSelectedAccount(acc)}
                          >
                            <td className="p-3">
                              <div className="font-medium">{acc.name}</div>
                              {acc.is_default && (
                                <Badge variant="secondary" className="text-xs mt-0.5">Default</Badge>
                              )}
                            </td>
                            <td className="p-3 text-muted-foreground">{acc.email}</td>
                            <td className="p-3">
                              <Badge variant="outline">{ACCOUNT_TYPE_LABELS[acc.account_type] || acc.account_type}</Badge>
                            </td>
                            <td className="p-3 text-center">
                              <Badge variant={acc.is_active ? 'default' : 'secondary'}>
                                {acc.is_active ? 'Active' : 'Inactive'}
                              </Badge>
                            </td>
                            <td className="p-3 text-center">
                              <Badge
                                variant={
                                  acc.test_status === 'success'
                                    ? 'default'
                                    : acc.test_status === 'failed'
                                      ? 'destructive'
                                      : 'secondary'
                                }
                              >
                                {acc.test_status === 'success' ? 'OK' : acc.test_status === 'failed' ? 'Failed' : 'Not tested'}
                              </Badge>
                            </td>
                            <td className="p-3 text-center font-medium">{acc.sent_count ?? 0}</td>
                            {/* <td className="p-3 text-center">{acc.opened_count ?? 0}</td> */}
                            <td className="p-3 text-center">{acc.clicked_count ?? 0}</td>
                            {/* <td className="p-3 text-center text-muted-foreground">
                              {(acc.open_rate ?? 0) > 0 ? `${acc.open_rate}%` : '—'}
                            </td> */}
                            {/* <td className="p-3 text-center text-muted-foreground">
                              {(acc.click_rate ?? 0) > 0 ? `${acc.click_rate}%` : '—'}
                            </td> */}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Right-side account details sidebar */}
            {selectedAccount && (
              <div className="w-[380px] shrink-0 flex flex-col rounded-lg border border-white/10 bg-black/20 backdrop-blur-sm shadow-sm overflow-hidden">
                <div className="flex items-center justify-between p-4 border-b border-white/10 bg-white/[0.03]">
                  <h3 className="font-semibold text-base text-white">Account details</h3>
                  <Button variant="ghost" size="icon" onClick={() => setSelectedAccount(null)} aria-label="Close">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  <div className="flex gap-2 items-center">
                    <p className="text-sm font-medium text-muted-foreground">Name</p>
                    <p className="font-medium">{selectedAccount.name}</p>
                    {selectedAccount.is_default && (
                      <Badge variant="secondary" className="mt-1">Default</Badge>
                    )}
                  </div>
                  <div className="flex gap-2 items-center">
                    <p className="text-sm font-medium text-muted-foreground">Email</p>
                    <p className="text-sm">{selectedAccount.email}</p>
                  </div>
                  <div className="flex gap-2 items-center">
                    <p className="text-sm font-medium text-muted-foreground">Type</p>
                    <Badge variant="outline">{ACCOUNT_TYPE_LABELS[selectedAccount.account_type] || selectedAccount.account_type}</Badge>
                  </div>
                  <div className="flex gap-2 items-center">
                    <p className="text-sm font-medium text-muted-foreground">Status</p>
                    <Badge variant={selectedAccount.is_active ? 'default' : 'secondary'}>
                      {selectedAccount.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="flex gap-2 items-center">
                    <p className="text-sm font-medium text-muted-foreground">Created</p>
                    <p className="text-sm">{formatDate(selectedAccount.created_at)}</p>
                  </div>
                  <div className="flex gap-2 items-center">
                    <p className="text-sm font-medium text-muted-foreground">Updated</p>
                    <p className="text-sm">{formatDate(selectedAccount.updated_at)}</p>
                  </div>
                  <div className="flex gap-2 items-center">
                    <p className="text-sm font-medium text-muted-foreground">Last tested</p>
                    <p className="text-sm">{formatDate(selectedAccount.last_tested_at) || 'Never'}</p>
                    <Badge
                      variant={
                        selectedAccount.test_status === 'success'
                          ? 'default'
                          : selectedAccount.test_status === 'failed'
                            ? 'destructive'
                            : 'secondary'
                      }
                    >
                      {selectedAccount.test_status === 'success' ? 'Success' : selectedAccount.test_status === 'failed' ? 'Failed' : 'Not tested'}
                    </Badge>
                    {selectedAccount.test_error && (
                      <p className="text-xs text-destructive mt-1 break-words">{selectedAccount.test_error}</p>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-2 border-t">
                    <div className="text-center">
                      <p className="text-lg font-semibold">{selectedAccount.sent_count ?? 0}</p>
                      <p className="text-xs text-muted-foreground">Sent</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold">{selectedAccount.opened_count ?? 0}</p>
                      <p className="text-xs text-muted-foreground">Opened</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-semibold">{selectedAccount.clicked_count ?? 0}</p>
                      <p className="text-xs text-muted-foreground">Clicked</p>
                    </div>
                  </div>
                  <div className="flex gap-6 text-sm text-muted-foreground justify-center">
                    <span>Open rate: {(selectedAccount.open_rate ?? 0) > 0 ? `${selectedAccount.open_rate}%` : '—'}</span>
                    <span>Click rate: {(selectedAccount.click_rate ?? 0) > 0 ? `${selectedAccount.click_rate}%` : '—'}</span>
                  </div>
                  <div className="flex flex-wrap gap-2 pt-2 border-t justify-center items-center">
                    <Button variant="outline" size="sm" onClick={() => openEditEmailAccount(selectedAccount.id)}>
                      <Pencil className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => openTestEmailAccount(selectedAccount)}>
                      <Send className="h-4 w-4 mr-1" />
                      Test
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      onClick={() => setDeleteConfirm({ id: selectedAccount.id, name: selectedAccount.name })}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Add/Edit email account modal */}
          <Dialog open={addOrEditModalOpen} onOpenChange={setAddOrEditModalOpen}>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingAccountId ? 'Edit email account' : 'Add email account'}</DialogTitle>
                <DialogDescription>SMTP settings for sending campaign emails. Leave password blank when editing to keep existing.</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleEmailSubmit}>
                <div className="space-y-4 py-4">
                  <div>
                    <Label>Account name *</Label>
                    <Input
                      value={emailForm.name}
                      onChange={(e) => setEmailForm((p) => ({ ...p, name: e.target.value }))}
                      placeholder="e.g. Main Gmail"
                    />
                  </div>
                  <div>
                    <Label>Account type</Label>
                    <Select value={emailForm.account_type} onValueChange={applyEmailTypeDefaults}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {EMAIL_ACCOUNT_TYPES.map((t) => (
                          <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Email *</Label>
                    <Input
                      type="email"
                      value={emailForm.email}
                      onChange={(e) => setEmailForm((p) => ({ ...p, email: e.target.value }))}
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <Label>SMTP host *</Label>
                    <Input
                      value={emailForm.smtp_host}
                      onChange={(e) => setEmailForm((p) => ({ ...p, smtp_host: e.target.value }))}
                      placeholder="smtp.gmail.com"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>SMTP port</Label>
                      <Input
                        type="number"
                        min={1}
                        max={65535}
                        value={emailForm.smtp_port}
                        onChange={(e) => setEmailForm((p) => ({ ...p, smtp_port: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label>SMTP username *</Label>
                      <Input
                        value={emailForm.smtp_username}
                        onChange={(e) => setEmailForm((p) => ({ ...p, smtp_username: e.target.value }))}
                        placeholder="Usually same as email"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>SMTP password / App password * {editingAccountId && '(leave blank to keep)'}</Label>
                    <Input
                      type="password"
                      value={emailForm.smtp_password}
                      onChange={(e) => setEmailForm((p) => ({ ...p, smtp_password: e.target.value }))}
                      placeholder="App password for Gmail"
                    />
                  </div>
                  <div className="flex flex-wrap gap-4">
                    <label className="flex items-center gap-2">
                      <input type="checkbox" checked={emailForm.use_tls} onChange={(e) => setEmailForm((p) => ({ ...p, use_tls: e.target.checked }))} />
                      <span className="text-sm">Use TLS</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" checked={emailForm.use_ssl} onChange={(e) => setEmailForm((p) => ({ ...p, use_ssl: e.target.checked }))} />
                      <span className="text-sm">Use SSL</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" checked={emailForm.is_gmail_app_password} onChange={(e) => setEmailForm((p) => ({ ...p, is_gmail_app_password: e.target.checked }))} />
                      <span className="text-sm">Gmail App Password</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" checked={emailForm.is_active} onChange={(e) => setEmailForm((p) => ({ ...p, is_active: e.target.checked }))} />
                      <span className="text-sm">Active</span>
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" checked={emailForm.is_default} onChange={(e) => setEmailForm((p) => ({ ...p, is_default: e.target.checked }))} />
                      <span className="text-sm">Default account</span>
                    </label>
                  </div>
                  <div>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={emailForm.enable_imap_sync}
                        onChange={(e) => {
                          setEmailForm((p) => ({ ...p, enable_imap_sync: e.target.checked }));
                          setShowImap(e.target.checked);
                        }}
                      />
                      <span className="text-sm">Enable IMAP sync (reply detection)</span>
                    </label>
                  </div>
                  {showImap && (
                    <div className="space-y-3 pt-2 border-t">
                      <Label>IMAP (optional)</Label>
                      <div className="grid grid-cols-2 gap-3">
                        <Input placeholder="IMAP host" value={emailForm.imap_host} onChange={(e) => setEmailForm((p) => ({ ...p, imap_host: e.target.value }))} />
                        <Input type="number" placeholder="Port" value={emailForm.imap_port} onChange={(e) => setEmailForm((p) => ({ ...p, imap_port: e.target.value }))} />
                      </div>
                      <Input placeholder="IMAP username" value={emailForm.imap_username} onChange={(e) => setEmailForm((p) => ({ ...p, imap_username: e.target.value }))} />
                      <Input type="password" placeholder="IMAP password" value={emailForm.imap_password} onChange={(e) => setEmailForm((p) => ({ ...p, imap_password: e.target.value }))} />
                      <label className="flex items-center gap-2">
                        <input type="checkbox" checked={emailForm.imap_use_ssl} onChange={(e) => setEmailForm((p) => ({ ...p, imap_use_ssl: e.target.checked }))} />
                        <span className="text-sm">IMAP use SSL</span>
                      </label>
                    </div>
                  )}
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setAddOrEditModalOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={emailFormLoading}>
                    {emailFormLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : editingAccountId ? 'Save' : 'Create'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>

          {/* Test email modal */}
          <Dialog open={testModalOpen} onOpenChange={setTestModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Send test email</DialogTitle>
                <DialogDescription>Enter the recipient address to verify this account.</DialogDescription>
              </DialogHeader>
              <div className="py-4">
                <Label>Test email address</Label>
                <Input
                  type="email"
                  value={testEmailTo}
                  onChange={(e) => setTestEmailTo(e.target.value)}
                  placeholder="recipient@example.com"
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setTestModalOpen(false)}>Cancel</Button>
                <Button onClick={handleTestEmailAccount} disabled={testLoading}>
                  {testLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Send test'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Delete confirm dialog */}
          <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Delete email account?</DialogTitle>
                <DialogDescription>
                  This will permanently delete &quot;{deleteConfirm?.name}&quot;. This action cannot be undone.
                </DialogDescription>
              </DialogHeader>
              <div className="flex justify-end gap-2 pt-4">
                <Button variant="outline" onClick={() => setDeleteConfirm(null)}>Cancel</Button>
                <Button
                  variant="destructive"
                  disabled={deleteLoading}
                  onClick={() => deleteConfirm && handleEmailDelete(deleteConfirm.id, deleteConfirm.name)}
                >
                  {deleteLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Delete'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="campaigns" className="!mt-2 min-h-[400px]">
          <Campaigns onRefresh={fetchStats} />
        </TabsContent>

        <TabsContent value="qa" className="!mt-2 h-[500px] overflow-y-auto min-h-[630px] scrollbar-black">
          <MarketingQA />
        </TabsContent>

        <TabsContent value="research" className="!mt-2 h-[500px] overflow-y-auto min-h-[630px] scrollbar-black">
          <MarketResearch />
        </TabsContent>

        <TabsContent value="documents">
          <Documents />
        </TabsContent>

        <TabsContent value="notifications">
          <Notifications onUnreadCountChange={fetchNotificationUnreadCount} />
        </TabsContent>

        <TabsContent value="saved-graphs" className="!mt-2">
          <Card className="border-white/10 bg-black/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-amber-500" />
                Saved Graph Prompts
              </CardTitle>
              <CardDescription className="text-white/60">
                Manage your saved graph prompts. Click View to preview saved chart data without regenerating.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {savedGraphsLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : savedGraphPrompts.length === 0 ? (
                <div className="text-center py-12">
                  <Sparkles className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                  <p className="text-muted-foreground">No saved graphs yet</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Go to the Q&A tab and save your graph prompts
                  </p>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {savedGraphPrompts.map((prompt) => (
                      <Card 
                        key={prompt.id} 
                        className={`flex flex-col cursor-pointer transition-all ${
                          viewingGraphId === prompt.id 
                            ? 'ring-2 ring-primary/50 bg-primary/5' 
                            : 'hover:border-primary/20'
                        }`}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <CardTitle className="text-sm line-clamp-2">{prompt.title}</CardTitle>
                              {prompt.tags && prompt.tags.length > 0 && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {prompt.tags.map((tag) => (
                                    <Badge key={tag} variant="secondary" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="flex-1 pb-3">
                          <p className="text-xs text-muted-foreground line-clamp-3">{prompt.prompt}</p>
                          {prompt.chart_type && (
                            <p className="text-xs mt-2 text-primary font-medium">
                              Chart Type: {prompt.chart_type}
                            </p>
                          )}
                        </CardContent>
                        <div className="flex gap-2 pt-3 border-t flex-wrap">
                          <Button
                            size="sm"
                            variant={viewingGraphId === prompt.id ? "default" : "outline"}
                            className="flex-1 text-xs h-8"
                            onClick={() => handleViewGraph(prompt)}
                          >
                            <>
                              <BarChart3 className="h-3 w-3 mr-1" />
                              View
                            </>
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-xs h-8 px-2"
                            onClick={() => handleDeleteGraphPrompt(prompt.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>

                  {/* Show saved graph preview */}
                  {viewingGraphResult && (
                    <Card className="border-primary/30 bg-primary/5">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              <BarChart3 className="h-5 w-5 text-primary" />
                              {viewingGraphResult.title || 'Saved Graph'}
                            </CardTitle>
                            {viewingGraphResult.insights && (
                              <CardDescription className="mt-2">
                                {Array.isArray(viewingGraphResult.insights) 
                                  ? viewingGraphResult.insights.join(' • ')
                                  : viewingGraphResult.insights
                                }
                              </CardDescription>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setViewingGraphId(null);
                              setViewingGraphResult(null);
                            }}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="bg-card rounded-lg p-6 border">
                          {viewingGraphResult.chart ? (
                            <div className="w-full overflow-x-auto">
                              {viewingGraphResult.chart.type === 'pie' && (
                                <div className="flex justify-center">
                                  {renderChart(viewingGraphResult.chart)}
                                </div>
                              )}
                              {['bar', 'line', 'area'].includes(viewingGraphResult.chart.type) && (
                                <div className="w-full">
                                  {renderChart(viewingGraphResult.chart)}
                                </div>
                              )}
                              {!['pie', 'bar', 'line', 'area'].includes(viewingGraphResult.chart.type) && (
                                <div className="text-center text-muted-foreground py-4">
                                  Chart type '{viewingGraphResult.chart.type}' not supported
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="text-center text-muted-foreground py-8">No chart data available</div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
    </div>
  );
};

export default MarketingDashboard;

